package dev.lumen;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.Items;

/**
 * Elytra ile uçarken seçilen X/Z hedefine doğru kendiliğinden yön verir ve yüksekliği korur.
 * Elinde havai fişek (firework) varsa ve hız düşükse otomatik kullanır.
 * Kullanım: /lumen elytra <x> <z>   (durdurmak için /lumen elytra stop)
 */
public final class ElytraTarget {
	/** Hedefe bu kadar yaklaşınca durur (blok). */
	private static final double ARRIVE_DISTANCE = 25;

	/** Seyir yüksekliği (Y). */
	public static double cruiseY = 200;

	private static boolean hasTarget;
	private static int targetX, targetZ;
	private static int rocketCooldown;

	private ElytraTarget() {
	}

	public static void setTarget(int x, int z) {
		targetX = x;
		targetZ = z;
		hasTarget = true;
		Module.ELYTRA.setEnabled(true);
		message("Hedef: §bX " + x + " Z " + z);
	}

	public static void stop() {
		hasTarget = false;
		Module.ELYTRA.setEnabled(false);
	}

	public static void onToggle(boolean on) {
		rocketCooldown = 0;
		if (on && !hasTarget) {
			message("Hedef yok. Önce §f/lumen elytra <x> <z> §7yaz");
		}
	}

	public static void tick() {
		if (!Module.ELYTRA.isEnabled() || !hasTarget) {
			return;
		}
		Minecraft mc = Minecraft.getInstance();
		LocalPlayer p = mc.player;
		if (p == null || !p.isFallFlying()) {
			return;
		}

		double dx = targetX + 0.5 - p.getX();
		double dz = targetZ + 0.5 - p.getZ();
		double dist = Math.sqrt(dx * dx + dz * dz);
		if (dist < ARRIVE_DISTANCE) {
			message("§aHedefe ulaşıldı");
			stop();
			return;
		}

		// yön: Minecraft yaw = atan2(-dx, dz)
		float targetYaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
		// yükseklik hatasına göre eğim: aşağıdaysak yukarı bak (negatif), yukarıdaysak hafif aşağı
		double error = cruiseY - p.getY();
		float targetPitch = Mth.clamp((float) (-error * 0.3), -35f, 20f);

		p.setYRot(Mth.approachDegrees(p.getYRot(), targetYaw, 6f));
		p.setXRot(Mth.approachDegrees(p.getXRot(), targetPitch, 3f));

		// hız düşükse ve elde havai fişek varsa kullan
		if (rocketCooldown > 0) {
			rocketCooldown--;
		} else {
			double horizontalSpeed = p.getDeltaMovement().horizontalDistance();
			if (horizontalSpeed < 0.9 && p.getMainHandItem().is(Items.FIREWORK_ROCKET) && mc.gameMode != null) {
				mc.gameMode.useItem(p, InteractionHand.MAIN_HAND);
				rocketCooldown = 30;
			}
		}
	}

	private static void message(String text) {
		Minecraft mc = Minecraft.getInstance();
		if (mc.player != null) {
			mc.player.displayClientMessage(Component.literal("§7[Lumen] " + text), false);
		}
	}
}
