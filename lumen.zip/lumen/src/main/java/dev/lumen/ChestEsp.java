package dev.lumen;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.entity.BarrelBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.entity.EnderChestBlockEntity;
import net.minecraft.world.level.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.world.level.block.entity.TrappedChestBlockEntity;
import net.minecraft.world.level.chunk.LevelChunk;

/**
 * Yakındaki sandık, varil, shulker ve ender chest'leri işaretler.
 * Açtığın konteynerler içeriğine göre renklenir:
 * boş = gri, dolu = yeşil, değerli = parlak camgöbeği. Açılmamışlar türüne göre renkli.
 */
public final class ChestEsp {
	/** Kaç chunk yarıçapında taransın. */
	public static int radiusChunks = 8;

	private static final List<EspRenderer.Box> CACHE = new ArrayList<>();
	private static int tickCounter;

	private ChestEsp() {
	}

	public static void reset() {
		CACHE.clear();
		tickCounter = 0;
	}

	public static void tick() {
		if (!Module.CHEST_ESP.isEnabled()) {
			return;
		}
		if (tickCounter++ % 10 != 0) {
			return;
		}
		Minecraft mc = Minecraft.getInstance();
		if (mc.level == null || mc.player == null) {
			return;
		}
		List<EspRenderer.Box> next = new ArrayList<>();
		int pcx = mc.player.chunkPosition().x;
		int pcz = mc.player.chunkPosition().z;

		for (int cx = pcx - radiusChunks; cx <= pcx + radiusChunks; cx++) {
			for (int cz = pcz - radiusChunks; cz <= pcz + radiusChunks; cz++) {
				if (!mc.level.hasChunk(cx, cz)) {
					continue;
				}
				LevelChunk chunk = mc.level.getChunk(cx, cz);
				for (BlockEntity be : chunk.getBlockEntities().values()) {
					float[] c = typeColor(be);
					if (c == null) {
						continue;
					}
					BlockPos p = be.getBlockPos();
					float fill = 0.25f;
					float line = 0.95f;
					double thick = 0.02;

					ContainerMemory.Status st = ContainerMemory.get(p);
					if (st == ContainerMemory.Status.EMPTY) {
						c = new float[]{0.5f, 0.5f, 0.5f};
						fill = 0.10f;
						line = 0.55f;
					} else if (st == ContainerMemory.Status.ITEMS) {
						c = new float[]{0.2f, 0.9f, 0.3f};
					} else if (st == ContainerMemory.Status.VALUABLE) {
						c = new float[]{0.1f, 1f, 1f};
						fill = 0.45f;
						thick = 0.045;
					}

					next.add(new EspRenderer.Box(p.getX(), p.getY(), p.getZ(), p.getX() + 1, p.getY() + 1, p.getZ() + 1,
							c[0], c[1], c[2], fill, true, false, 0));
					next.add(new EspRenderer.Box(p.getX(), p.getY(), p.getZ(), p.getX() + 1, p.getY() + 1, p.getZ() + 1,
							c[0], c[1], c[2], line, false, true, thick));
				}
			}
		}
		CACHE.clear();
		CACHE.addAll(next);
	}

	public static void collect() {
		if (!Module.CHEST_ESP.isEnabled()) {
			return;
		}
		for (EspRenderer.Box b : CACHE) {
			EspRenderer.submit(b);
		}
	}

	/** Henüz açılmamış konteynerler için tür rengi; ilgilenmediğimiz blok varlığı için null. */
	private static float[] typeColor(BlockEntity be) {
		if (be instanceof TrappedChestBlockEntity) {
			return new float[]{1f, 0.2f, 0.2f}; // tuzaklı sandık: kırmızı
		}
		if (be instanceof ChestBlockEntity) {
			return new float[]{1f, 0.65f, 0.1f}; // sandık: turuncu
		}
		if (be instanceof BarrelBlockEntity) {
			return new float[]{0.75f, 0.5f, 0.25f}; // varil: kahverengi
		}
		if (be instanceof ShulkerBoxBlockEntity) {
			return new float[]{1f, 0.3f, 0.9f}; // shulker: pembe
		}
		if (be instanceof EnderChestBlockEntity) {
			return new float[]{0.6f, 0.2f, 1f}; // ender chest: mor
		}
		return null;
	}
}
