package dev.lumen;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;

/** Lumen HUD: logo, FPS, ping, koordinat ve aktif modül listesi (ArrayList). */
public final class Hud {
	private static final int ACCENT = 0xFF6A3DE8;
	private static final int BACKDROP = 0x90000000;

	private Hud() {
	}

	public static void init() {
		HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
				Identifier.fromNamespaceAndPath("lumen", "hud"), Hud::render);
	}

	private static void render(GuiGraphics g, DeltaTracker deltaTracker) {
		if (!Module.HUD.isEnabled()) {
			return;
		}
		Minecraft mc = Minecraft.getInstance();
		if (mc.player == null || mc.options.hideGui) {
			return;
		}
		Font font = mc.font;
		drawInfoPanel(g, mc, font);
		drawModuleList(g, mc, font);
	}

	// ---------- sol üst: logo + bilgiler ----------

	private static void drawInfoPanel(GuiGraphics g, Minecraft mc, Font font) {
		int fps = mc.getFps();
		String ping;
		PlayerInfo info = mc.getConnection() == null ? null : mc.getConnection().getPlayerInfo(mc.player.getUUID());
		if (mc.hasSingleplayerServer() || info == null) {
			ping = "-";
		} else {
			ping = info.getLatency() + "ms";
		}
		String stats = "FPS " + fps + "  Ping " + ping;
		String coords = "XYZ " + mc.player.getBlockX() + " " + mc.player.getBlockY() + " " + mc.player.getBlockZ();
		String edition = Edition.FREE ? "FREE" : "PRO";

		int logoW = font.width("LUMEN") + 4 + font.width(edition);
		int w = Math.max(logoW, Math.max(font.width(stats), font.width(coords))) + 10;
		int h = 38;

		g.fill(4, 4, 4 + w, 4 + h, BACKDROP);
		g.fill(4, 4, 6, 4 + h, ACCENT);

		// gradyan logo: mor -> camgöbeği
		String name = "LUMEN";
		int x = 10;
		for (int i = 0; i < name.length(); i++) {
			float hue = Mth.lerp(i / (float) (name.length() - 1), 0.74f, 0.50f);
			int color = 0xFF000000 | Mth.hsvToRgb(hue, 0.6f, 1.0f);
			String ch = String.valueOf(name.charAt(i));
			g.drawString(font, ch, x, 8, color, true);
			x += font.width(ch);
		}
		g.drawString(font, edition, x + 4, 8, Edition.FREE ? 0xFFAAAAAA : 0xFFFFC857, true);

		g.drawString(font, stats, 10, 19, 0xFFFFFFFF, true);
		g.drawString(font, coords, 10, 29, 0xFFDDDDDD, true);
	}

	// ---------- sağ üst: aktif modül listesi ----------

	private static void drawModuleList(GuiGraphics g, Minecraft mc, Font font) {
		List<String> lines = new ArrayList<>();
		for (Module m : Module.values()) {
			if (m.isEnabled() && m != Module.HUD) {
				lines.add(m.title);
			}
		}
		lines.sort(Comparator.comparingInt((String s) -> font.width(s)).reversed());

		int screenW = mc.getWindow().getGuiScaledWidth();
		int y = 4;
		for (int i = 0; i < lines.size(); i++) {
			String text = lines.get(i);
			int tw = font.width(text);
			int x = screenW - tw - 8;
			float hue = (0.74f - i * 0.04f) % 1.0f;
			int color = 0xFF000000 | Mth.hsvToRgb(hue < 0 ? hue + 1f : hue, 0.55f, 1.0f);

			g.fill(x - 3, y - 1, screenW - 2, y + 9, BACKDROP);
			g.fill(screenW - 2, y - 1, screenW, y + 9, color);
			g.drawString(font, text, x, y, color, true);
			y += 11;
		}
	}
}
