package dev.lumen;

import java.util.HashMap;
import java.util.Map;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.ShulkerBoxMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BarrelBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.ShulkerBoxBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.ChestType;

import net.fabricmc.fabric.api.event.player.UseBlockCallback;

/**
 * Açtığın sandık/varil/shulker'ların içeriğini hatırlar.
 * (Sunucu, içeriği sen açmadan istemciye göndermez; bu yüzden uzaktan bakılamaz.)
 */
public final class ContainerMemory {
	public enum Status {
		EMPTY("BOŞ"), ITEMS("DOLU"), VALUABLE("DEĞERLİ");

		public final String label;

		Status(String label) {
			this.label = label;
		}
	}

	private static final Map<Long, Status> MAP = new HashMap<>();
	private static volatile BlockPos pendingPos;
	private static Level lastLevel;
	private static int openTicks;

	private ContainerMemory() {
	}

	public static void init() {
		UseBlockCallback.EVENT.register((player, level, hand, hit) -> {
			if (level.isClientSide()) {
				pendingPos = hit.getBlockPos();
			}
			return InteractionResult.PASS;
		});
	}

	public static Status get(BlockPos pos) {
		return MAP.get(pos.asLong());
	}

	public static int count(Status s) {
		int n = 0;
		for (Status v : MAP.values()) {
			if (v == s) {
				n++;
			}
		}
		return n;
	}

	public static void tick() {
		Minecraft mc = Minecraft.getInstance();
		if (mc.level == null || mc.player == null) {
			return;
		}
		if (mc.level != lastLevel) {
			MAP.clear();
			lastLevel = mc.level;
			pendingPos = null;
			openTicks = 0;
		}

		AbstractContainerMenu menu = mc.player.containerMenu;
		boolean container = menu instanceof ChestMenu || menu instanceof ShulkerBoxMenu;
		BlockPos pos = pendingPos;
		if (!container || mc.screen == null || pos == null) {
			openTicks = 0;
			return;
		}
		BlockState state = mc.level.getBlockState(pos);
		Block block = state.getBlock();
		// ender chest kişiye özeldir, kaydetmiyoruz
		if (!(block instanceof ChestBlock || block instanceof BarrelBlock || block instanceof ShulkerBoxBlock)) {
			return;
		}
		// içerik paketinin gelmesi için birkaç tick bekle
		if (++openTicks < 5) {
			return;
		}

		Status status = Status.EMPTY;
		for (Slot slot : menu.slots) {
			if (slot.container instanceof Inventory) {
				continue; // kendi envanterin
			}
			ItemStack stack = slot.getItem();
			if (stack.isEmpty()) {
				continue;
			}
			if (isValuable(stack)) {
				status = Status.VALUABLE;
				break;
			}
			status = Status.ITEMS;
		}

		Status old = MAP.put(pos.asLong(), status);
		// çift sandığın diğer yarısı
		if (block instanceof ChestBlock && state.getValue(ChestBlock.TYPE) != ChestType.SINGLE) {
			MAP.put(pos.relative(ChestBlock.getConnectedDirection(state)).asLong(), status);
		}
		if (old != status) {
			mc.player.displayClientMessage(Component.literal("§7[Lumen] Konteyner: "
					+ (status == Status.VALUABLE ? "§b" : status == Status.ITEMS ? "§a" : "§8") + status.label), true);
		}
	}

	private static boolean isValuable(ItemStack stack) {
		if (stack.isEnchanted()) {
			return true;
		}
		String path = BuiltInRegistries.ITEM.getKey(stack.getItem()).getPath();
		return path.startsWith("netherite_") || path.startsWith("diamond")
				|| path.contains("shulker_box") || path.equals("ancient_debris")
				|| path.equals("enchanted_golden_apple") || path.equals("totem_of_undying")
				|| path.equals("elytra") || path.equals("nether_star") || path.equals("beacon")
				|| path.equals("end_crystal") || path.equals("dragon_egg") || path.equals("trident")
				|| path.equals("mace") || path.equals("heavy_core") || path.equals("emerald_block")
				|| path.equals("experience_bottle") || path.equals("golden_apple");
	}
}
