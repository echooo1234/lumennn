package dev.lumen;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;

/** Kullanım kolaylığı: Auto-Walk (kendiliğinden yürü) ve Toggle Sprint (kendiliğinden koş). */
public final class QolModules {
	private static boolean sprintForced;

	private QolModules() {
	}

	public static void onAutoWalkToggle(boolean on) {
		if (!on) {
			Minecraft.getInstance().options.keyUp.setDown(false);
		}
	}

	public static void tick() {
		Minecraft mc = Minecraft.getInstance();
		LocalPlayer p = mc.player;
		if (p == null || Module.FREECAM.isEnabled()) {
			return;
		}

		// Auto-Walk: geri (S) tuşuna basınca kapanır
		if (Module.AUTO_WALK.isEnabled()) {
			if (mc.options.keyDown.isDown()) {
				Module.AUTO_WALK.setEnabled(false);
			} else if (mc.screen == null) {
				mc.options.keyUp.setDown(true);
			}
		}

		// Toggle Sprint: ileri giderken kendiliğinden koş
		if (Module.TOGGLE_SPRINT.isEnabled() && mc.screen == null) {
			boolean forward = mc.options.keyUp.isDown();
			if (forward && !p.isShiftKeyDown()) {
				mc.options.keySprint.setDown(true);
				sprintForced = true;
			} else if (sprintForced) {
				mc.options.keySprint.setDown(false);
				sprintForced = false;
			}
		} else if (sprintForced) {
			mc.options.keySprint.setDown(false);
			sprintForced = false;
		}
	}
}
