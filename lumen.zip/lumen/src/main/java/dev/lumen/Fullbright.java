package dev.lumen;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;

/**
 * Fullbright: istemci tarafında uzun süreli bir "gece görüşü" efekti verir.
 * Efekt sadece kendi ekranında etkilidir; sunucu bunu bilmez.
 */
public final class Fullbright {
	private static final int DURATION = 1_000_000;

	private Fullbright() {
	}

	public static void onToggle(boolean on) {
		if (!on) {
			remove();
		}
	}

	public static void tick() {
		if (!Module.FULLBRIGHT.isEnabled()) {
			return;
		}
		LocalPlayer p = Minecraft.getInstance().player;
		if (p == null) {
			return;
		}
		if (p.getEffect(MobEffects.NIGHT_VISION) == null) {
			p.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, DURATION, 0, false, false, false));
		}
	}

	/** Sadece bizim verdiğimiz (çok uzun süreli) efekti kaldırır; sunucunun verdiğine dokunmaz. */
	private static void remove() {
		LocalPlayer p = Minecraft.getInstance().player;
		if (p == null) {
			return;
		}
		MobEffectInstance cur = p.getEffect(MobEffects.NIGHT_VISION);
		if (cur != null && cur.getDuration() > DURATION / 2) {
			p.removeEffect(MobEffects.NIGHT_VISION);
		}
	}
}
