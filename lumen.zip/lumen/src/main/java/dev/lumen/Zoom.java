package dev.lumen;

import net.minecraft.util.Mth;

/** Dürbün mantığında pürüzsüz yakınlaştırma: tuşu basılı tut, fare tekerleğiyle seviyeyi ayarla. */
public final class Zoom {
	/** Yakınlaştırma katı (2 = iki kat). */
	public static double level = 4.0;

	private static boolean active;
	private static double current = 1.0; // 1 = zoom yok

	private Zoom() {
	}

	public static void setActive(boolean value) {
		active = value;
	}

	public static boolean isActive() {
		return active;
	}

	public static void scroll(double amount) {
		level = Mth.clamp(level + Math.signum(amount) * 0.5, 1.5, 12.0);
	}

	/** FOV çarpanı (1 = değişmez, küçük = yakın). Her çizimde yumuşakça hedefe yaklaşır. */
	public static float fovScale() {
		double target = active ? 1.0 / level : 1.0;
		current += (target - current) * 0.25;
		if (Math.abs(target - current) < 0.001) {
			current = target;
		}
		return (float) current;
	}
}
