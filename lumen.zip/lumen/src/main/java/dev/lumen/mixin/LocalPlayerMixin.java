package dev.lumen.mixin;

import dev.lumen.Module;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import net.minecraft.client.player.LocalPlayer;

/** Clear Water: su altı görüş değerini en yükseğe çeker (daha net, daha uzak görüş). */
@Mixin(LocalPlayer.class)
public abstract class LocalPlayerMixin {
	@Inject(method = "getWaterVision", at = @At("HEAD"), cancellable = true)
	private void lumen$clearWater(CallbackInfoReturnable<Float> cir) {
		if (Module.CLEAR_WATER.isEnabled()) {
			cir.setReturnValue(1.0f);
		}
	}
}
