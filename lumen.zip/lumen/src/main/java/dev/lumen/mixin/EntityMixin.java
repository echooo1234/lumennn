package dev.lumen.mixin;

import dev.lumen.Freecam;
import dev.lumen.Module;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;

/** Freecam açıkken fare, karakteri değil kamerayı döndürür. */
@Mixin(Entity.class)
public abstract class EntityMixin {
	@Inject(method = "turn", at = @At("HEAD"), cancellable = true)
	private void lumen$turn(double yRot, double xRot, CallbackInfo ci) {
		if (Module.FREECAM.isEnabled() && (Object) this == Minecraft.getInstance().player) {
			Freecam.turn(yRot, xRot);
			ci.cancel();
		}
	}
}
