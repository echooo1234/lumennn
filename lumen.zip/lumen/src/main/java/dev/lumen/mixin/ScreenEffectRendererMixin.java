package dev.lumen.mixin;

import dev.lumen.Module;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import net.minecraft.client.renderer.ScreenEffectRenderer;

/** Low Fire: ekranı kaplayan yanma (alev) efektini çizmez. */
@Mixin(ScreenEffectRenderer.class)
public abstract class ScreenEffectRendererMixin {
	// require = 0: hedef metot bu sürümde farklıysa oyun açılışı bozulmaz (sadece efekt çalışmaz)
	@Inject(method = "renderFire", at = @At("HEAD"), cancellable = true, require = 0)
	private static void lumen$lowFire(CallbackInfo ci) {
		if (Module.LOW_FIRE.isEnabled()) {
			ci.cancel();
		}
	}
}
