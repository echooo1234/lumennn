package dev.lumen.mixin;

import dev.lumen.Zoom;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import net.minecraft.client.renderer.GameRenderer;

/** Zoom: görüş açısını (FOV) küçültür. */
@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
	@Inject(method = "getFov", at = @At("RETURN"), cancellable = true, require = 0)
	private void lumen$zoomFov(CallbackInfoReturnable<Float> cir) {
		float scale = Zoom.fovScale();
		if (scale != 1.0f) {
			cir.setReturnValue(cir.getReturnValue() * scale);
		}
	}
}
