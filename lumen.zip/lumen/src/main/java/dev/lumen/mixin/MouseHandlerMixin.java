package dev.lumen.mixin;

import dev.lumen.Zoom;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import net.minecraft.client.MouseHandler;

/** Zoom açıkken fare tekerleği yakınlaştırma seviyesini ayarlar (hotbar kaymaz). */
@Mixin(MouseHandler.class)
public abstract class MouseHandlerMixin {
	@Inject(method = "onScroll", at = @At("HEAD"), cancellable = true, require = 0)
	private void lumen$scroll(long window, double xOffset, double yOffset, CallbackInfo ci) {
		if (Zoom.isActive() && yOffset != 0) {
			Zoom.scroll(yOffset);
			ci.cancel();
		}
	}
}
