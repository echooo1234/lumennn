package dev.lumen;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.client.Minecraft;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;

/** Nether portalı, End portalı ve End portal çerçevelerini işaretler. */
public final class PortalEsp {
	public static int radiusChunks = 6;
	private static final int MAX_BLOCKS = 3000;

	private record Hit(int x, int y, int z, float r, float g, float b) {
	}

	private static final List<Hit> CACHE = new ArrayList<>();
	private static int tickCounter;

	private PortalEsp() {
	}

	public static void reset() {
		CACHE.clear();
		tickCounter = 0;
	}

	private static boolean isPortalState(BlockState s) {
		return s.is(Blocks.NETHER_PORTAL) || s.is(Blocks.END_PORTAL) || s.is(Blocks.END_PORTAL_FRAME);
	}

	public static void tick() {
		if (!Module.PORTAL_ESP.isEnabled()) {
			return;
		}
		if (tickCounter++ % 20 != 0) {
			return;
		}
		Minecraft mc = Minecraft.getInstance();
		if (mc.level == null || mc.player == null) {
			return;
		}
		List<Hit> next = new ArrayList<>();
		int pcx = mc.player.chunkPosition().x;
		int pcz = mc.player.chunkPosition().z;

		outer:
		for (int cx = pcx - radiusChunks; cx <= pcx + radiusChunks; cx++) {
			for (int cz = pcz - radiusChunks; cz <= pcz + radiusChunks; cz++) {
				if (!mc.level.hasChunk(cx, cz)) {
					continue;
				}
				LevelChunk chunk = mc.level.getChunk(cx, cz);
				LevelChunkSection[] sections = chunk.getSections();
				for (int i = 0; i < sections.length; i++) {
					LevelChunkSection section = sections[i];
					if (section.hasOnlyAir() || !section.maybeHas(PortalEsp::isPortalState)) {
						continue;
					}
					int baseY = chunk.getSectionYFromSectionIndex(i) << 4;
					for (int x = 0; x < 16; x++) {
						for (int y = 0; y < 16; y++) {
							for (int z = 0; z < 16; z++) {
								BlockState s = section.getBlockState(x, y, z);
								if (!isPortalState(s)) {
									continue;
								}
								float r, g, b;
								if (s.is(Blocks.NETHER_PORTAL)) {
									r = 0.6f; g = 0.2f; b = 1f; // nether: mor
								} else if (s.is(Blocks.END_PORTAL)) {
									r = 0.1f; g = 1f; b = 0.6f; // end portalı: yeşil
								} else {
									r = 0.3f; g = 0.9f; b = 0.4f; // end çerçevesi: açık yeşil
								}
								next.add(new Hit((cx << 4) + x, baseY + y, (cz << 4) + z, r, g, b));
								if (next.size() >= MAX_BLOCKS) {
									break outer;
								}
							}
						}
					}
				}
			}
		}
		CACHE.clear();
		CACHE.addAll(next);
	}

	public static void collect() {
		if (!Module.PORTAL_ESP.isEnabled()) {
			return;
		}
		for (Hit h : CACHE) {
			EspRenderer.block(h.x(), h.y(), h.z(), h.r(), h.g(), h.b());
		}
	}
}
