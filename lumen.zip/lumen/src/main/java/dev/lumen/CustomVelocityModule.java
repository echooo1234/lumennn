package dev.lumen;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

/**
 * İstemci tarafı hız vektörü ile serbest uçuş: tuşlara göre hedef hız hesaplanır,
 * mevcut hız her tick bu hedefe doğru yumuşakça yaklaştırılır (ivmelenme/yavaşlama).
 * İleri/geri/sağ/sol: yatay, Space: yukarı, Shift: aşağı, tuş yoksa havada asılı kalır.
 * Ağ paketlerine dokunmaz; sunucu hareket kontrolü yapıyorsa fark edebilir.
 * Elytra ile süzülürken (fall flying) devreye girmez.
 */
public final class CustomVelocityModule {
	/** Yatay hız (blok/tick). Dikey hız bunun %70'idir. */
	public static double speed = 0.3;

	/** Her tick hedef hıza ne kadar yaklaşılacağı (0-1). Küçük = daha yumuşak. */
	private static final double SMOOTHING = 0.25;

	private CustomVelocityModule() {
	}

	public static void tick() {
		if (!Module.VELOCITY.isEnabled() || Module.FREECAM.isEnabled()) {
			return;
		}
		Minecraft mc = Minecraft.getInstance();
		LocalPlayer p = mc.player;
		if (p == null || mc.screen != null || p.isFallFlying()) {
			return;
		}

		double fwd = (mc.options.keyUp.isDown() ? 1 : 0) - (mc.options.keyDown.isDown() ? 1 : 0);
		double side = (mc.options.keyRight.isDown() ? 1 : 0) - (mc.options.keyLeft.isDown() ? 1 : 0);
		double vert = (mc.options.keyJump.isDown() ? 1 : 0) - (mc.options.keyShift.isDown() ? 1 : 0);

		double yaw = Math.toRadians(p.getYRot());
		// ileri = (-sin, cos), sağ = (-cos, -sin)
		double dx = -Math.sin(yaw) * fwd - Math.cos(yaw) * side;
		double dz = Math.cos(yaw) * fwd - Math.sin(yaw) * side;
		double len = Math.sqrt(dx * dx + dz * dz);

		double tx = 0;
		double tz = 0;
		if (len > 1e-6) {
			tx = dx / len * speed;
			tz = dz / len * speed;
		}
		double ty = vert * speed * 0.7;

		Vec3 v = p.getDeltaMovement();
		p.setDeltaMovement(Mth.lerp(SMOOTHING, v.x, tx), Mth.lerp(SMOOTHING, v.y, ty), Mth.lerp(SMOOTHING, v.z, tz));
	}
}
