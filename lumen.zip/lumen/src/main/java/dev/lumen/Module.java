package dev.lumen;

import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;

/** Açılıp kapanabilen modüller ve durumları. */
public enum Module {
	PLAYER_ESP("playeresp", "Oyuncu ESP", false),
	CHEST_ESP("chestesp", "Sandık ESP", false),
	PORTAL_ESP("portalesp", "Portal ESP", false),
	BASE_FINDER("basefinder", "Base Bulucu", false),
	ANTI_VANISH("antivanish", "Anti Vanish", false),
	FREECAM("freecam", "Freecam", false),
	SPEED("speed", "Hız", true),
	ELYTRA("elytra", "Elytra Hedef", true),
	ELYTRA_BOOST("elytraboost", "Elytra Boost", true),
	VELOCITY("velocity", "Velocity Uçuş", true),
	// ücretsiz yaşam kalitesi / görsel modüller
	HUD("hud", "HUD", false),
	FULLBRIGHT("fullbright", "Fullbright", false),
	LOW_FIRE("lowfire", "Low Fire", false),
	CLEAR_WATER("clearwater", "Clear Water", false),
	AUTO_WALK("autowalk", "Auto-Walk", false),
	TOGGLE_SPRINT("togglesprint", "Toggle Sprint", false),
	ZOOM("zoom", "Custom Zoom", false);

	public final String id;
	public final String title;
	/** true ise sadece pro sürümde açılabilir. */
	public final boolean proOnly;
	private boolean enabled;

	Module(String id, String title, boolean proOnly) {
		this.id = id;
		this.title = title;
		this.proOnly = proOnly;
	}

	public boolean isLocked() {
		return proOnly && Edition.FREE;
	}

	public boolean isEnabled() {
		return enabled;
	}

	/** Dünyadan çıkınca kapanmayan (ayar gibi davranan) modüller. */
	private boolean isPersistent() {
		return this == HUD || this == FULLBRIGHT || this == LOW_FIRE || this == CLEAR_WATER
				|| this == TOGGLE_SPRINT || this == ZOOM;
	}

	public void toggle() {
		setEnabled(!enabled);
	}

	public void setEnabled(boolean value) {
		if (value == enabled) {
			return;
		}
		Minecraft mc = Minecraft.getInstance();
		if (value && isLocked()) {
			if (mc.player != null) {
				mc.player.displayClientMessage(
						Component.literal("§7[Lumen] §f" + title + " §6sadece pro sürümde"), true);
			}
			return;
		}
		if (value && this == FREECAM && mc.player == null) {
			return;
		}
		enabled = value;
		switch (this) {
			case FREECAM -> Freecam.onToggle(value);
			case ANTI_VANISH -> AntiVanish.reset();
			case BASE_FINDER -> BaseFinder.reset();
			case CHEST_ESP -> ChestEsp.reset();
			case PORTAL_ESP -> PortalEsp.reset();
			case ELYTRA -> ElytraTarget.onToggle(value);
			case FULLBRIGHT -> Fullbright.onToggle(value);
			case AUTO_WALK -> QolModules.onAutoWalkToggle(value);
			default -> {
			}
		}
		if (mc.player != null) {
			mc.player.displayClientMessage(
					Component.literal("§7[Lumen] §f" + title + (value ? " §aAÇIK" : " §cKAPALI")), true);
		}
	}

	public static Module byId(String id) {
		for (Module m : values()) {
			if (m.id.equalsIgnoreCase(id)) {
				return m;
			}
		}
		return null;
	}

	/** Dünyadan çıkınca kalıcı olmayan modülleri kapatır. */
	public static void disableAll() {
		for (Module m : values()) {
			if (!m.isPersistent()) {
				m.enabled = false;
			}
		}
		Freecam.onToggle(false);
	}
}
