package dev.lumen;

import java.util.Locale;

import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.network.chat.Component;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;

/**
 * Ücretsiz sürüm kısıtı: sunucu adresi {@link #REQUIRED_SERVER} içermiyorsa bağlantıyı keser.
 * Tek kişilik dünyalarda (sunucu adresi yoktur) bir kısıtlama uygulanmaz.
 * Sürüm bilgisi {@link Edition} sınıfından gelir; bu sınıf derleme sırasında üretilir
 * (varsayılan ücretsiz, "gradlew build -Pedition=pro" ile pro).
 */
public final class ServerGuard {
	/** Sunucu adresinde (küçük harfe çevrilmiş) aranan metin. */
	public static final String REQUIRED_SERVER = "donutsmp";

	public static final String KICK_MESSAGE = "Disconnected by Lumen Client: donutsmp only lol";

	private ServerGuard() {
	}

	public static void init() {
		ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
			if (!Edition.FREE) {
				return;
			}
			ServerData server = client.getCurrentServer();
			if (server == null) {
				return; // tek kişilik dünya
			}
			String ip = server.ip == null ? "" : server.ip.toLowerCase(Locale.ROOT);
			if (!ip.contains(REQUIRED_SERVER)) {
				client.execute(() -> handler.getConnection().disconnect(Component.literal(KICK_MESSAGE)));
			}
		});
	}
}
