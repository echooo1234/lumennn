package dev.lumen;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.phys.Vec3;

/**
 * Yürürken yatay hızı artırır (vanilla sprint hızının katı).
 * Basit bir hız çarpanıdır; sunucu hareket kontrolü yapıyorsa fark edebilir.
 */
public final class SpeedHack {
	/** Vanilla sprint hızı (blok/tick) yaklaşık 0.2158. */
	private static final double BASE = 0.2158;

	/** Çarpan: 1.0 = vanilla. */
	public static double multiplier = 1.5;

	private SpeedHack() {
	}

	public static void tick() {
		if (!Module.SPEED.isEnabled() || Module.FREECAM.isEnabled()) {
			return;
		}
		Minecraft mc = Minecraft.getInstance();
		LocalPlayer p = mc.player;
		if (p == null || mc.screen != null || p.isFallFlying() || p.isInWater() || p.isInLava()
				|| p.onClimbable() || p.getAbilities().flying) {
			return;
		}

		double fwd = (mc.options.keyUp.isDown() ? 1 : 0) - (mc.options.keyDown.isDown() ? 1 : 0);
		double side = (mc.options.keyRight.isDown() ? 1 : 0) - (mc.options.keyLeft.isDown() ? 1 : 0);
		if (fwd == 0 && side == 0) {
			return;
		}

		double yaw = Math.toRadians(p.getYRot());
		// ileri = (-sin, cos), sağ = (-cos, -sin)
		double dx = -Math.sin(yaw) * fwd - Math.cos(yaw) * side;
		double dz = Math.cos(yaw) * fwd - Math.sin(yaw) * side;
		double len = Math.sqrt(dx * dx + dz * dz);
		if (len < 1e-6) {
			return;
		}
		double speed = BASE * multiplier;
		Vec3 v = p.getDeltaMovement();
		p.setDeltaMovement(dx / len * speed, v.y, dz / len * speed);
	}
}
