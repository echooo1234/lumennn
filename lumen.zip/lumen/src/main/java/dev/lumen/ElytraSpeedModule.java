package dev.lumen;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.phys.Vec3;

/**
 * Elytra ile uçarken hızı {@link #boostMultiplier} ile çarpar.
 * Çarpan her tick uygulandığı için küçük değerler bile zamanla hızlanma sağlar;
 * hız {@link #maxSpeed} değerini geçmez. Değer menüden elle ayarlanır.
 * W basılıyken ya da Elytra Hedef açıkken çalışır.
 */
public final class ElytraSpeedModule {
	/** Tick başına hız çarpanı. 1.0 = etkisiz (varsayılan). */
	public static float boostMultiplier = 1.0f;

	/** En yüksek hız (blok/tick). */
	public static double maxSpeed = 1.8;

	private ElytraSpeedModule() {
	}

	public static void tick() {
		if (!Module.ELYTRA_BOOST.isEnabled() || boostMultiplier <= 1.0f) {
			return;
		}
		Minecraft mc = Minecraft.getInstance();
		LocalPlayer p = mc.player;
		if (p == null || mc.screen != null || !p.isFallFlying()) {
			return;
		}
		if (!mc.options.keyUp.isDown() && !Module.ELYTRA.isEnabled()) {
			return;
		}
		Vec3 v = p.getDeltaMovement();
		if (v.length() >= maxSpeed) {
			return;
		}
		Vec3 next = v.scale(boostMultiplier);
		if (next.length() > maxSpeed) {
			next = next.normalize().scale(maxSpeed);
		}
		p.setDeltaMovement(next);
	}
}
