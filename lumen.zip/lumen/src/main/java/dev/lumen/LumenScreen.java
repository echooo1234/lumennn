package dev.lumen;

import java.util.function.DoubleConsumer;
import java.util.function.DoubleSupplier;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Wurst tarzı basit menü: modülleri açıp kapatır, birkaç ayarı değiştirir. */
public class LumenScreen extends Screen {
	private static int page = 0; // 0: ana modüller, 1: görünüm / kolaylık
	private int columns = 4;
	private static final int COL_W = 132;
	private static final int GAP = 8;
	private static final int ROW = 24;
	private static final int HEADER = 20;
	private static final int ROWS = 6;

	private int left;
	private int top;

	public LumenScreen() {
		super(Component.literal("Lumen"));
	}

	@Override
	protected void init() {
		columns = page == 0 ? 4 : 2;
		int totalW = columns * COL_W + (columns - 1) * GAP;
		left = (this.width - totalW) / 2;
		top = this.height / 2 - 70;
		int y = top + HEADER + 6;

		if (page == 1) {
			initPageTwo(y);
			addFooter();
			return;
		}

		// 1. pencere: Görsel
		int x = colX(0);
		moduleButton(x, y, Module.PLAYER_ESP);
		moduleButton(x, y + ROW, Module.CHEST_ESP);
		moduleButton(x, y + 2 * ROW, Module.PORTAL_ESP);
		cycleButton(x, y + 3 * ROW, "Sandık yarıçapı", new double[]{4, 6, 8, 12, 16},
				() -> ChestEsp.radiusChunks, v -> ChestEsp.radiusChunks = (int) v);

		// 2. pencere: Bulucu
		x = colX(1);
		moduleButton(x, y, Module.BASE_FINDER);
		moduleButton(x, y + ROW, Module.ANTI_VANISH);
		cycleButton(x, y + 2 * ROW, "Base yarıçapı", new double[]{4, 6, 8, 10, 14, 20},
				() -> BaseFinder.radiusChunks, v -> BaseFinder.radiusChunks = (int) v);
		cycleButton(x, y + 3 * ROW, "Base eşiği", new double[]{3, 6, 10, 15, 25, 40},
				() -> BaseFinder.threshold, v -> BaseFinder.threshold = v);

		// 3. pencere: Kamera
		x = colX(2);
		moduleButton(x, y, Module.FREECAM);
		cycleButton(x, y + ROW, "Freecam hızı", new double[]{0.3, 0.6, 0.9, 1.5, 2.5, 4},
				() -> Freecam.speed, v -> Freecam.speed = v);
		moduleButton(x, y + 2 * ROW, Module.VELOCITY);
		cycleButton(x, y + 3 * ROW, "Uçuş hızı", new double[]{0.1, 0.2, 0.3, 0.5, 0.8},
				() -> CustomVelocityModule.speed, v -> CustomVelocityModule.speed = v);

		// 4. pencere: Hareket (pro)
		x = colX(3);
		moduleButton(x, y, Module.SPEED);
		cycleButton(x, y + ROW, "Hız çarpanı", new double[]{1.0, 1.25, 1.5, 2.0, 2.5},
				() -> SpeedHack.multiplier, v -> SpeedHack.multiplier = v);
		moduleButton(x, y + 2 * ROW, Module.ELYTRA);
		cycleButton(x, y + 3 * ROW, "Seyir yüksekliği", new double[]{120, 160, 200, 250, 300},
				() -> ElytraTarget.cruiseY, v -> ElytraTarget.cruiseY = v);
		moduleButton(x, y + 4 * ROW, Module.ELYTRA_BOOST);
		cycleButton(x, y + 5 * ROW, "Boost çarpanı", new double[]{1.0, 1.02, 1.05, 1.1, 1.2},
				() -> ElytraSpeedModule.boostMultiplier, v -> ElytraSpeedModule.boostMultiplier = (float) v);

		addFooter();
	}

	private void initPageTwo(int y) {
		int x = colX(0);
		moduleButton(x, y, Module.HUD);
		moduleButton(x, y + ROW, Module.FULLBRIGHT);
		moduleButton(x, y + 2 * ROW, Module.LOW_FIRE);
		moduleButton(x, y + 3 * ROW, Module.CLEAR_WATER);

		x = colX(1);
		moduleButton(x, y, Module.AUTO_WALK);
		moduleButton(x, y + ROW, Module.TOGGLE_SPRINT);
		moduleButton(x, y + 2 * ROW, Module.ZOOM);
		cycleButton(x, y + 3 * ROW, "Zoom katı", new double[]{2, 3, 4, 6, 8, 12},
				() -> Zoom.level, v -> Zoom.level = v);
	}

	private void addFooter() {
		int fy = top + HEADER + 6 + ROWS * ROW + 10;
		this.addRenderableWidget(Button.builder(
				Component.literal(page == 0 ? "Sayfa 2 »" : "« Sayfa 1"), b -> {
					page = 1 - page;
					this.rebuildWidgets();
				}).bounds(this.width / 2 - 105, fy, 100, 20).build());
		this.addRenderableWidget(Button.builder(Component.literal("Kapat"), b -> this.onClose())
				.bounds(this.width / 2 + 5, fy, 100, 20).build());
	}

	private int colX(int column) {
		return left + column * (COL_W + GAP);
	}

	private void moduleButton(int x, int y, Module m) {
		this.addRenderableWidget(Button.builder(moduleLabel(m), b -> {
			m.toggle();
			b.setMessage(moduleLabel(m));
		}).bounds(x + 5, y, COL_W - 10, 20).build());
	}

	private static Component moduleLabel(Module m) {
		if (m.isLocked()) {
			return Component.literal(m.title + ": §6[PRO]");
		}
		return Component.literal(m.title + ": " + (m.isEnabled() ? "§aAÇIK" : "§cKAPALI"));
	}

	/** Tıklayınca değerler arasında döner. */
	private void cycleButton(int x, int y, String name, double[] values, DoubleSupplier get, DoubleConsumer set) {
		this.addRenderableWidget(Button.builder(cycleLabel(name, get.getAsDouble()), b -> {
			double cur = get.getAsDouble();
			int next = 0;
			for (int i = 0; i < values.length; i++) {
				if (values[i] > cur + 1e-4) {
					next = i;
					break;
				}
			}
			set.accept(values[next]);
			b.setMessage(cycleLabel(name, values[next]));
		}).bounds(x + 5, y, COL_W - 10, 20).build());
	}

	private static Component cycleLabel(String name, double v) {
		double r = Math.round(v * 1000) / 1000.0;
		String s = Math.abs(r - Math.rint(r)) < 1e-9 ? String.valueOf((long) Math.rint(r)) : String.valueOf(r);
		return Component.literal(name + ": §e" + s);
	}

	@Override
	public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
		super.renderBackground(g, mouseX, mouseY, partialTick);
		String[] titles = page == 0
				? new String[]{"Görsel", "Bulucu", "Kamera/Uçuş", "Hareket"}
				: new String[]{"Görünüm", "Kolaylık"};
		int bodyH = HEADER + 6 + ROWS * ROW + 6;
		for (int i = 0; i < columns; i++) {
			int x = colX(i);
			g.fill(x, top, x + COL_W, top + bodyH, 0xCC14141C); // pencere gövdesi
			g.fill(x, top, x + COL_W, top + HEADER, 0xFF6A3DE8); // başlık çubuğu
			g.drawCenteredString(this.font, Component.literal(titles[i]), x + COL_W / 2, top + 6, 0xFFFFFFFF);
		}
	}

	@Override
	public boolean isPauseScreen() {
		return false; // menü açıkken oyun durmasın
	}
}
