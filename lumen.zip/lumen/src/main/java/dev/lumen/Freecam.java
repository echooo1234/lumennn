package dev.lumen;

import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

/** Serbest kamera: karakterin yerinde kalır, kamera özgürce gezer. */
public final class Freecam {
	/** Tick başına blok. */
	public static double speed = 0.9;

	private static double x, y, z;
	private static double px, py, pz;
	private static float yaw, pitch;

	private Freecam() {
	}

	public static void onToggle(boolean on) {
		Minecraft mc = Minecraft.getInstance();
		if (on && mc.player != null) {
			Vec3 eye = mc.player.getEyePosition();
			x = px = eye.x;
			y = py = eye.y;
			z = pz = eye.z;
			yaw = mc.player.getYRot();
			pitch = mc.player.getXRot();
		}
	}

	/** Fare hareketi: karakter yerine kamerayı döndürür (EntityMixin çağırır). */
	public static void turn(double yRot, double xRot) {
		yaw += (float) (yRot * 0.15);
		pitch = Mth.clamp(pitch + (float) (xRot * 0.15), -90f, 90f);
	}

	public static void tick() {
		if (!Module.FREECAM.isEnabled()) {
			return;
		}
		Minecraft mc = Minecraft.getInstance();
		px = x;
		py = y;
		pz = z;
		if (mc.screen != null) {
			return;
		}

		double fwd = (mc.options.keyUp.isDown() ? 1 : 0) - (mc.options.keyDown.isDown() ? 1 : 0);
		double side = (mc.options.keyRight.isDown() ? 1 : 0) - (mc.options.keyLeft.isDown() ? 1 : 0);
		double vert = (mc.options.keyJump.isDown() ? 1 : 0) - (mc.options.keyShift.isDown() ? 1 : 0);

		double yawRad = Math.toRadians(yaw);
		double pitchRad = Math.toRadians(pitch);
		double fx = -Math.sin(yawRad) * Math.cos(pitchRad);
		double fy = -Math.sin(pitchRad);
		double fz = Math.cos(yawRad) * Math.cos(pitchRad);
		double rx = -Math.cos(yawRad);
		double rz = -Math.sin(yawRad);

		double dx = fx * fwd + rx * side;
		double dy = fy * fwd + vert;
		double dz = fz * fwd + rz * side;
		double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
		if (len > 1e-6) {
			double s = speed * (mc.options.keySprint.isDown() ? 2.5 : 1.0) / len;
			x += dx * s;
			y += dy * s;
			z += dz * s;
		}
	}

	// Kamera mixin'i bunları okur
	public static double camX(float partial) {
		return Mth.lerp((double) partial, px, x);
	}

	public static double camY(float partial) {
		return Mth.lerp((double) partial, py, y);
	}

	public static double camZ(float partial) {
		return Mth.lerp((double) partial, pz, z);
	}

	public static float yaw() {
		return yaw;
	}

	public static float pitch() {
		return pitch;
	}
}
