# Lumen (Minecraft 1.21.11, Fabric)

Sadece görsel yardımcılar: oyuncu/sandık/portal ESP, base bulucu, anti-vanish, freecam.
Hareket veya combat hilesi yok.

## Kontroller

| Modül | Tuş | Komut |
|---|---|---|
| Menü | Sol Shift | - |
| Freecam | V | `/lumen freecam` |
| Oyuncu ESP | Numpad 1 | `/lumen playeresp` |
| Sandık ESP | Numpad 2 | `/lumen chestesp` |
| Portal ESP | Numpad 3 | `/lumen portalesp` |
| Base Bulucu | Numpad 4 | `/lumen basefinder` |
| Anti Vanish | Numpad 5 | `/lumen antivanish` |
| Hız (pro) | Numpad 6 | `/lumen speed` |
| Elytra Hedef (pro) | Numpad 7 | `/lumen elytra <x> <z>` |
| Elytra Boost (pro) | Numpad 8 | `/lumen elytraboost` |
| Velocity Uçuş (pro) | Numpad 9 | `/lumen velocity` |

Tuşlar Ayarlar > Kontroller > Lumen bölümünden değiştirilebilir.

Menü varsayılan olarak Sol Shift ile açılır. Sol Shift aynı zamanda eğilme (sneak) tuşu olduğu için
eğilirken de menü açılır; rahatsız ederse Kontroller'den "Menü" tuşunu (örn. Sağ Shift) değiştir.

## Sandık renkleri (Sandık ESP)
- Açılmamış: türüne göre (sandık turuncu, tuzaklı kırmızı, varil kahverengi, shulker pembe, ender mor)
- Açtığın ve boş olan: gri
- Açtığın ve içinde eşya olan: yeşil
- Açtığın ve içinde değerli eşya olan (elmas, netherite, büyülü eşya, shulker, totem, elytra vb.): parlak camgöbeği

Sunucu, bir konteynerin içini sen açmadan göndermediği için renk ancak açtıktan sonra değişir.
Bilgi sadece oyun oturumu boyunca hatırlanır.

## Hareket (sadece pro)
- **Hız:** yürürken yatay hızı çarpanla artırır (menüden 1.0-2.5x).
- **Elytra Hedef:** `/lumen elytra <x> <z>` ile hedef seç, elytra ile uçarken oraya yönelir ve seyir yüksekliğini korur.
  Elinde havai fişek varsa ve hız düşükse otomatik kullanır. Durdurmak için `/lumen elytra stop`.
- **Elytra Boost** (`ElytraSpeedModule`): elytra ile uçarken W basılıyken (ya da Elytra Hedef açıkken) hızı `boostMultiplier` ile çarpar.
  Varsayılan 1.0 (etkisiz); menüden 1.0-1.2 arasında elle ayarlanır. Çarpan her tick uygulanır, hız 1.8 blok/tick'i geçmez.

- **Velocity Uçuş** (`CustomVelocityModule`): hız vektörünü yumuşakça hedefe yaklaştırarak serbest uçuş. WASD yatay, Space yukarı, Shift aşağı, tuş yoksa havada asılı kalır. Elytra ile süzülürken devreye girmez.

Bu özellikler basit hız/yön değişiklikleridir. Sunucunun hareket kontrolü varsa fark edilebilir.
Ücretsiz sürümde bu modüller kilitlidir.

Diğer komutlar:
- `/lumen bases` - bulunan olası base'leri listeler (en yüksek puan önce)
- `/lumen speed <0.05-10>` - freecam hızı (Ctrl ile 2.5 kat)
- `/lumen radius <2-32>` - tarama yarıçapı (chunk)
- `/lumen esik <puan>` - base bulucu eşiği (varsayılan 6)

## Ücretsiz sürüm kısıtı
Sürüm derleme sırasında belirlenir (ayar dosyası yoktur). Varsayılan derleme ücretsizdir: adresinde
"donutsmp" geçmeyen sunuculara girince bağlantı "Disconnected by Lumen Client: donutsmp only lol"
mesajıyla kesilir. Tek kişilik dünyalarda kısıt yoktur.

- Ücretsiz jar: `gradlew build` -> `build/libs/lumen-free-1.0.0.jar`
- Kısıtsız (pro) jar: `gradlew build -Pedition=pro` -> `build/libs/lumen-pro-1.0.0.jar`

## Derleme

### Yöntem 1: Kendi bilgisayarında
1. JDK 21 kur (Temurin 21 önerilir).
2. Bu klasörde: `gradlew.bat build` (Windows) veya `./gradlew build`
3. `build/libs/lumen-free-1.0.0.jar` (pro için `lumen-pro-1.0.0.jar`) dosyasını (`-sources` olmayanı) `.minecraft/mods` klasörüne koy.
4. Gerekenler: Fabric Loader 0.18+ ve Fabric API (1.21.11 için 0.141.x).

### Yöntem 2: GitHub Actions ile (kurulum yok)
Klasörü kendi GitHub deposuna yükle, Actions sekmesinde "build" çalışınca
"lumen-jar" artifact'ini indir.

## Notlar
- Freecam açıkken tıklamalar hâlâ karakterin baktığı yere gider (dikkat).
- Base bulucu puanlama sezgiseldir; köy, kale, maden gibi yapılar da puan alabilir.
- Anti-vanish, sunucudan komut önerilerini isteyip tab listesiyle karşılaştırır.
  Bazı sunucularda çalışmayabilir veya yanlış pozitif verebilir.
- Çoğu çok oyunculu sunucuda bu tür özellikler yasaktır; kullanmadan önce kuralları kontrol et.

## Ücretsiz görünüm / kolaylık modülleri (free + pro)

Menüde **Sayfa 2** altında:

| Modül | Açıklama |
|---|---|
| HUD | Logo, FPS, ping, koordinat ve aktif modül listesi |
| Fullbright | İstemci tarafı gece görüşü (karanlık/mağara net görünür) |
| Low Fire | Ekranı kaplayan alev efektini gizler |
| Clear Water | Su altı görüşünü netleştirir |
| Auto-Walk | Kendiliğinden ileri yürür (S ile kapanır) |
| Toggle Sprint | İleri giderken kendiliğinden koşar |
| Custom Zoom | **C** basılı tut; fare tekerleğiyle seviye değişir |

Item Physics ve Motion Blur şimdilik yok (shader/render pipeline gerektirir).
